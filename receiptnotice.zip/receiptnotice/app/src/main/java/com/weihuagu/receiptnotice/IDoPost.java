package com.weihuagu.receiptnotice;
import java.util.Map;

public interface IDoPost{
        public  void doPost(Map<String, String> params);
}
