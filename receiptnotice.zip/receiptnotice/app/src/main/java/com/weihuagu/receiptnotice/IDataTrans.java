package com.weihuagu.receiptnotice;
import java.util.Map;                                  
public interface IDataTrans{
    public Map<String,String> transferMapValue(Map<String, String> params);

}
