package com.weihuagu.receiptnotice;
import android.service.notification.StatusBarNotification;

public interface ActionStatusBarNotification{
        public void removeNotification(StatusBarNotification sbn);
}
